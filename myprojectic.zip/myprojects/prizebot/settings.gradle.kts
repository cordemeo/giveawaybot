rootProject.name = "prizebot"

include("bot")
include("bot:telegram")
include("fsm")
include("db-migrations")
include("random")
include("random:jsonRPC")
include("utils")
include("conditions")
