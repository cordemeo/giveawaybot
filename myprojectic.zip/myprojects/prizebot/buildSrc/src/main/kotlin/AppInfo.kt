object AppInfo {
    const val PACKAGE = "me.y9san9.prizebot"
    const val VERSION = "2.0"
}
