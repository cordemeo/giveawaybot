class Plugins internal constructor() {
    val jvm = "jvm"
    val serialization = "plugin.serialization"
}

val plugin = Plugins()
