plugins {
    kotlin(plugin.jvm)
}

dependencies {
    implementation(ktorCore)
    implementation(serialization)
}
