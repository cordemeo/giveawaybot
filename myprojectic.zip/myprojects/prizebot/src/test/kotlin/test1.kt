import org.junit.jupiter.api.Assertions.assertEquals
import org.junit.jupiter.api.Assertions.assertThrows
import org.junit.jupiter.api.Test

/**
 * Тесты для функции selectRandomWinner.
 */
class RandomWinnerTest {

    /**
     * Проверяет корректность выбора победителя из списка участников.
     */
    @Test
    fun `should select a random winner from participants`() {
        val participants = listOf(1, 2, 3, 4, 5)
        val winner = selectRandomWinner(participants)
        assert(participants.contains(winner)) { "Победитель должен быть в списке участников" }
    }

    /**
     * Проверяет, что функция выбрасывает исключение для пустого списка.
     */
    @Test
    fun `should throw exception for empty participants list`() {
        val participants = emptyList<Int>()
        assertThrows(IllegalArgumentException::class.java) {
            selectRandomWinner(participants)
        }
    }
}