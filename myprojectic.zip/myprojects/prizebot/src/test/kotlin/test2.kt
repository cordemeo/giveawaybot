import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test

/**
 * Тесты для конечного автомата состояний.
 */
class StateManagerTest {

    /**
     * Проверяет, что состояние пользователя корректно изменяется.
     */
    @Test
    fun `should change user state`() {
        val stateManager = StateManager()
        val userId = 123L

        stateManager.changeState(userId, "awaiting_input")
        val currentState = stateManager.getState(userId)

        assertEquals("awaiting_input", currentState, "Состояние должно обновляться корректно")
    }

    /**
     * Проверяет, что обработчик состояния вызывается корректно.
     */
    @Test
    fun `should call state handler`() {
        val stateHandler = mockk<(String) -> Unit>(relaxed = true)
        val stateManager = StateManager()
        val userId = 123L

        stateManager.registerHandler("awaiting_input", stateHandler)
        stateManager.changeState(userId, "awaiting_input")

        verify { stateHandler.invoke("awaiting_input") }
    }
}