import io.mockk.mockk
import io.mockk.verify
import org.junit.jupiter.api.Test

/**
 * Тесты для основного класса BotMain.
 */
class BotMainTest {

    /**
     * Проверяет, что бот обрабатывает обновления.
     */
    @Test
    fun `should process updates`() {
        val mockApi = mockk<TelegramApi>(relaxed = true)
        val botMain = BotMain("test_token", mockApi)

        val update = mockk<Update>()
        botMain.onUpdateReceived(update)

        verify { mockApi.processUpdate(update) }
    }

    /**
     * Проверяет, что бот корректно запускается.
     */
    @Test
    fun `should start bot successfully`() {
        val mockApi = mockk<TelegramApi>(relaxed = true)
        val botMain = BotMain("test_token", mockApi)

        botMain.startBot()
        verify { mockApi.connect() }
    }
}
