plugins {
    kotlin(plugin.jvm)
}

dependencies {
    implementation(exposed)
    implementation(utils)
}
