package me.y9san9.extensions.any


@Suppress("unused")
val Any?.unit get() = Unit
