package me.y9san9.telegram.updates.primitives


interface FromChatUpdate {
    val chatId: Long
}
