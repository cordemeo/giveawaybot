package me.y9san9.telegram.updates.primitives


interface LocalizedUpdate {
    val languageCode: String?
}
