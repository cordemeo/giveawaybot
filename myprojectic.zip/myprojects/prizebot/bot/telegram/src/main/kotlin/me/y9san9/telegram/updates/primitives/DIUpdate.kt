package me.y9san9.telegram.updates.primitives


interface DIUpdate<out DI> {
    val di: DI
}
