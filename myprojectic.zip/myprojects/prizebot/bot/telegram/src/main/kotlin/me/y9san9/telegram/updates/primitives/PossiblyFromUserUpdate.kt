package me.y9san9.telegram.updates.primitives


interface PossiblyFromUserUpdate {
    val userId: Long?
}
