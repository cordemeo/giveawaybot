package me.y9san9.telegram.updates.primitives


interface HasTextUpdate {
    val text: String?
}
