package me.y9san9.prizebot.database.migrations


val databaseMigrations = listOf(`Migration 0-1`, `Migration 1-2`)
