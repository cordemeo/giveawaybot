package me.y9san9.prizebot.resources.images


object Image {
    val socialPreview by resourceImage
}
